"""
Unified Prompt Builder

Combines material facts, voice traits, and anti-AI instructions
into single prompt to minimize detection.

Single-pass generation reduces "AI layers" that detectors flag.

Now supports flexible component types and content domains through
ComponentRegistry and DomainContext.
"""

import logging
import os
import random
from typing import Any, Dict, Optional, Tuple

from generation.config.text_field_config_service import (
    load_text_field_config,
    resolve_text_field_entry,
)
from shared.text.utils.component_specs import ComponentRegistry, DomainContext
from shared.text.utils.prompt_registry_service import PromptRegistryService

logger = logging.getLogger(__name__)


class PromptBuilder:
    """
    Builds unified prompts for AI-resistant generation.
    
    Key strategies:
    - Inject real facts to ground content
    - Add ESL voice traits from start
    - Include deliberate imperfections
    - Vary structure dynamically
    - Avoid formulaic patterns
    
    Now supports:
    - Dynamic component types via ComponentRegistry
    - Multiple content domains via DomainContext
    - Flexible prompt building without hardcoding
    """
    
    _technical_profiles_cache = None  # Cache for technical profiles
    _rhythm_profiles_cache = None  # Cache for rhythm profiles
    _text_field_config_cache = None  # Cache for generation/text_field_config.yaml
    _shared_text_prompt_core_cache = None  # Cache for catalog.shared.textPromptCore
    _sentence_structure_cache = None  # Cache for shared/config/sentence_structure.yaml
    _prompt_compaction_cache = None  # Cache for prompt_compaction config
    _length_gate_cache = None  # Cache for length_gate config
    _domain_config_cache: Dict[str, Dict[str, Any]] = {}  # Cache for domains/*/config.yaml
    _length_variation_history_cache: Dict[str, list[int]] = {}
    
    @staticmethod
    def _load_technical_profiles() -> Dict:
        """Load technical profiles from YAML file (cached)."""
        if PromptBuilder._technical_profiles_cache is None:
            import yaml
            profiles_path = os.path.join('prompts', 'registry', 'technical_profiles.yaml')
            if not os.path.exists(profiles_path):
                raise FileNotFoundError(
                    f"Technical profiles file not found or invalid at prompts/registry/technical_profiles.yaml. "
                    "Fail-fast architecture requires this file."
                )
            with open(profiles_path, 'r', encoding='utf-8') as f:
                PromptBuilder._technical_profiles_cache = yaml.safe_load(f)
            logger.debug(f"Loaded technical profiles from {profiles_path}")
        return PromptBuilder._technical_profiles_cache
    
    @staticmethod
    def _load_rhythm_profiles() -> Dict:
        """Load rhythm profiles from YAML file (cached)."""
        if PromptBuilder._rhythm_profiles_cache is None:
            import yaml
            profiles_path = os.path.join('prompts', 'registry', 'rhythm_profiles.yaml')
            if not os.path.exists(profiles_path):
                raise FileNotFoundError(
                    f"Rhythm profiles file not found or invalid at prompts/registry/rhythm_profiles.yaml. "
                    "Fail-fast architecture requires this file."
                )
            with open(profiles_path, 'r', encoding='utf-8') as f:
                PromptBuilder._rhythm_profiles_cache = yaml.safe_load(f)
            logger.debug(f"Loaded rhythm profiles from {profiles_path}")
        return PromptBuilder._rhythm_profiles_cache

    @staticmethod
    def _load_text_field_config() -> Dict:
        """Load centralized text field config from YAML file (cached)."""
        if PromptBuilder._text_field_config_cache is None:
            PromptBuilder._text_field_config_cache = load_text_field_config()

            if not PromptBuilder._text_field_config_cache:
                raise ValueError("Text field config is empty: generation/text_field_config.yaml")

        return PromptBuilder._text_field_config_cache

    @staticmethod
    def _load_shared_text_prompt_core() -> str:
        """Load reusable centralized text prompting core from prompt catalog (cached)."""
        if PromptBuilder._shared_text_prompt_core_cache is None:
            PromptBuilder._shared_text_prompt_core_cache = PromptRegistryService.get_shared_text_prompt_core().strip()

            if not PromptBuilder._shared_text_prompt_core_cache:
                raise ValueError("Shared text prompt core is empty in prompts/registry/prompt_catalog.yaml")

        return PromptBuilder._shared_text_prompt_core_cache

    @staticmethod
    def _load_length_gate_config() -> Dict:
        """Load length gate config from generation/config.yaml (cached)."""
        if PromptBuilder._length_gate_cache is None:
            from generation.config.config_loader import get_config

            config = get_config()
            PromptBuilder._length_gate_cache = config.get_length_gate_config()

        return PromptBuilder._length_gate_cache

    @staticmethod
    def _load_domain_config(domain: str) -> Dict[str, Any]:
        """Load domain config from domains/{domain}/config.yaml (cached)."""
        if domain not in PromptBuilder._domain_config_cache:
            import yaml

            config_path = os.path.join('domains', domain, 'config.yaml')
            if not os.path.exists(config_path):
                raise FileNotFoundError(
                    f"Domain config file not found at {config_path}. "
                    "Fail-fast architecture requires this file."
                )

            with open(config_path, 'r', encoding='utf-8') as file_handle:
                domain_config = yaml.safe_load(file_handle)

            if not isinstance(domain_config, dict):
                raise ValueError(f"Domain config must be a YAML dictionary: {config_path}")

            PromptBuilder._domain_config_cache[domain] = domain_config

        return PromptBuilder._domain_config_cache[domain]

    @staticmethod
    def _strip_subject_suffix_for_prompt(topic: str, domain: str) -> str:
        """Strip configured domain frontmatter suffix from topic for prompt `{subject}` usage."""
        domain_config = PromptBuilder._load_domain_config(domain)
        frontmatter_pattern = domain_config.get('frontmatter_pattern')
        if not isinstance(frontmatter_pattern, str) or '{slug}' not in frontmatter_pattern:
            raise ValueError(
                f"Domain config missing valid frontmatter_pattern with '{{slug}}': domains/{domain}/config.yaml"
            )

        pattern_without_ext = frontmatter_pattern[:-5] if frontmatter_pattern.endswith('.yaml') else frontmatter_pattern
        suffix = pattern_without_ext.split('{slug}', 1)[1]

        if suffix and topic.endswith(suffix):
            stripped_topic = topic[:-len(suffix)]
            return stripped_topic or topic

        domain_suffix = f"-{domain}"
        if topic.endswith(domain_suffix):
            stripped_topic = topic[:-len(domain_suffix)]
            return stripped_topic or topic

        return topic

    @staticmethod
    def _resolve_prompt_category(item_data: Dict[str, Any], domain: str) -> str:
        """Resolve prompt category as parent taxonomy value (never domain label)."""
        raw_category = item_data.get('category', '')
        category = raw_category.strip() if isinstance(raw_category, str) else ''

        if category and category.lower() != domain.lower():
            return category

        raw_subcategory = item_data.get('subcategory', '')
        subcategory = raw_subcategory.strip() if isinstance(raw_subcategory, str) else ''
        if subcategory:
            return subcategory

        return category

    @staticmethod
    def _has_word_length_spec(*prompt_sections: str) -> bool:
        """Check if any prompt section already declares WORD LENGTH instruction."""
        for section in prompt_sections:
            if isinstance(section, str) and 'WORD LENGTH:' in section.upper():
                return True
        return False

    @staticmethod
    def _build_length_instruction(component_type: str, base_length: int, faq_count: Optional[int]) -> str:
        """Build mandatory length instruction using length gate config."""
        length_gate = PromptBuilder._load_length_gate_config()
        min_factor = length_gate['min_factor']
        max_factor = length_gate['max_factor']
        buffer_factor = length_gate['instruction_max_buffer_factor']

        if component_type == 'faq':
            text_field_config = PromptBuilder._load_text_field_config()
            answer_base = PromptBuilder._resolve_base_length(
                text_field_config=text_field_config,
                component_type='faqAnswer',
                fallback_length=ComponentRegistry.get_default_length('faqAnswer'),
            )
            min_words = max(1, int(round(answer_base * min_factor)))
            max_words = max(min_words, int(round(answer_base * max_factor)))
            hard_limit_words = max(min_words, int(max_words * buffer_factor))
            answer_count = faq_count if isinstance(faq_count, int) and faq_count > 0 else 3
            return (
                f"WORD LENGTH: {min_words}-{max_words} words per answer ({answer_count} answers). "
                f"HARD LIMIT: Do not exceed {hard_limit_words} per answer. "
                "Count words and rewrite until within range."
            )

        min_words = max(1, int(round(base_length * min_factor)))
        max_words = max(min_words, int(round(base_length * max_factor)))
        hard_limit_words = max(min_words, int(max_words * buffer_factor))
        return (
            f"WORD LENGTH: {min_words}-{max_words} words. "
            f"HARD LIMIT: Do not exceed {hard_limit_words}. "
            "Count words and rewrite until within range."
        )

    @staticmethod
    def _resolve_field_config_entry(text_field_config: Dict[str, Any], component_type: str) -> Optional[Dict[str, Any]]:
        """Resolve field config by exact key, alias, and nested section suffix."""
        return resolve_text_field_entry(component_type, text_field_config)

    @staticmethod
    def _resolve_base_length(
        text_field_config: Dict[str, Any],
        component_type: str,
        fallback_length: int,
    ) -> int:
        """Resolve base length from per-field config, defaults, then fallback."""
        defaults_cfg = text_field_config.get('defaults', {})
        default_base = defaults_cfg.get('base_length') if isinstance(defaults_cfg, dict) else None
        if default_base is not None and not isinstance(default_base, int):
            raise ValueError("defaults.base_length must be an integer in generation/text_field_config.yaml")

        field_entry = PromptBuilder._resolve_field_config_entry(text_field_config, component_type)
        if isinstance(field_entry, dict) and 'base_length' in field_entry:
            base_length = field_entry.get('base_length')
            if not isinstance(base_length, int) or base_length <= 0:
                raise ValueError(
                    f"Invalid base_length for '{component_type}' in generation/text_field_config.yaml"
                )
            return base_length

        if isinstance(default_base, int) and default_base > 0:
            return default_base

        return fallback_length

    @staticmethod
    def _resolve_field_factor_override(
        text_field_config: Dict[str, Any],
        component_type: str,
        factor_min: float,
        factor_max: float,
    ) -> tuple[float, float]:
        """Apply optional per-field min/max factor override from config."""
        field_entry = PromptBuilder._resolve_field_config_entry(text_field_config, component_type)
        if not isinstance(field_entry, dict):
            return factor_min, factor_max

        override_min = field_entry.get('min_factor')
        override_max = field_entry.get('max_factor')

        if override_min is None and override_max is None:
            return factor_min, factor_max
        if not isinstance(override_min, (int, float)) or not isinstance(override_max, (int, float)):
            raise ValueError(
                f"min_factor/max_factor overrides for '{component_type}' must be numeric"
            )

        randomization_cfg = text_field_config.get('randomization_range')
        if not isinstance(randomization_cfg, dict):
            raise ValueError(
                "Missing required config block: randomization_range in generation/text_field_config.yaml"
            )

        global_min = randomization_cfg.get('min_factor')
        global_max = randomization_cfg.get('max_factor')
        if not isinstance(global_min, (int, float)) or not isinstance(global_max, (int, float)):
            raise ValueError(
                "randomization_range.min_factor/max_factor must be numeric"
            )

        resolved_min = float(override_min)
        resolved_max = float(override_max)
        if resolved_min <= 0 or resolved_max <= 0 or resolved_min > resolved_max:
            raise ValueError(
                f"Invalid min_factor/max_factor override for '{component_type}'"
            )
        if resolved_min < float(global_min) or resolved_max > float(global_max):
            raise ValueError(
                f"Factor overrides for '{component_type}' must stay within randomization_range"
            )

        return resolved_min, resolved_max

    @staticmethod
    def _resolve_pattern_factor_range(
        text_field_config: Dict,
        randomization_cfg: Dict,
        variation_pattern: Optional[str],
    ) -> tuple[float, float]:
        """Resolve min/max randomization factor for a variation pattern."""
        min_factor = randomization_cfg.get('min_factor')
        max_factor = randomization_cfg.get('max_factor')

        if not isinstance(min_factor, (int, float)) or not isinstance(max_factor, (int, float)):
            raise ValueError(
                "text_length_randomization.min_factor and max_factor must be numeric"
            )
        if min_factor <= 0 or max_factor <= 0 or min_factor > max_factor:
            raise ValueError(
                f"Invalid text_length_randomization range: min_factor={min_factor}, max_factor={max_factor}"
            )

        if not variation_pattern:
            return float(min_factor), float(max_factor)

        variation_patterns_cfg = text_field_config.get('variation_patterns')
        if not isinstance(variation_patterns_cfg, dict):
            raise ValueError(
                "Missing required config block: variation_patterns in generation/text_field_config.yaml"
            )

        bands = variation_patterns_cfg.get('bands')
        if not isinstance(bands, dict):
            raise ValueError(
                "variation_patterns.bands must be a mapping in generation/text_field_config.yaml"
            )

        band = bands.get(variation_pattern)
        if not isinstance(band, dict):
            raise ValueError(
                f"Missing variation pattern band for '{variation_pattern}' in generation/text_field_config.yaml"
            )

        band_min = band.get('min_factor')
        band_max = band.get('max_factor')
        if not isinstance(band_min, (int, float)) or not isinstance(band_max, (int, float)):
            raise ValueError(
                f"variation_patterns.bands.{variation_pattern}.min_factor/max_factor must be numeric"
            )
        if band_min <= 0 or band_max <= 0 or band_min > band_max:
            raise ValueError(
                f"Invalid variation band for '{variation_pattern}': min_factor={band_min}, max_factor={band_max}"
            )
        if band_min < min_factor or band_max > max_factor:
            raise ValueError(
                f"variation_patterns.bands.{variation_pattern} must stay within randomization_range"
            )

        return float(band_min), float(band_max)

    @staticmethod
    def _resolve_variation_instruction(
        text_field_config: Dict,
        variation_pattern: Optional[str],
    ) -> Optional[str]:
        """Resolve human-readable variation instruction for the selected pattern."""
        if not variation_pattern:
            return None

        variation_patterns_cfg = text_field_config.get('variation_patterns')
        if not isinstance(variation_patterns_cfg, dict):
            raise ValueError(
                "Missing required config block: variation_patterns in generation/text_field_config.yaml"
            )

        instructions = variation_patterns_cfg.get('instructions')
        if not isinstance(instructions, dict):
            raise ValueError(
                "variation_patterns.instructions must be a mapping in generation/text_field_config.yaml"
            )

        instruction = instructions.get(variation_pattern)
        if not isinstance(instruction, str) or not instruction.strip():
            raise ValueError(
                f"Missing variation pattern instruction for '{variation_pattern}' in generation/text_field_config.yaml"
            )

        return instruction.strip()

    @staticmethod
    def _select_variation_factor_with_memory(
        domain: str,
        component_type: str,
        base_length: int,
        rng,
        factor_min: float,
        factor_max: float,
    ) -> Tuple[float, int]:
        """Select variation factor with bounded anti-repeat resampling."""
        if base_length <= 0:
            raise ValueError("base_length must be > 0")

        length_gate_config = PromptBuilder._load_length_gate_config()
        memory_size = length_gate_config['variation_memory_size']
        min_gap_words = length_gate_config['variation_min_gap_words']
        max_resamples = length_gate_config['variation_max_resamples']

        history_key = f"{domain}:{component_type}"
        history = PromptBuilder._length_variation_history_cache.setdefault(history_key, [])

        sampled: list[Tuple[float, int]] = []
        chosen: Optional[Tuple[float, int]] = None

        for _ in range(max_resamples):
            factor = rng.uniform(factor_min, factor_max)
            candidate_length = max(1, int(round(base_length * factor)))
            sampled.append((factor, candidate_length))

            if all(abs(candidate_length - prior_length) >= min_gap_words for prior_length in history):
                chosen = (factor, candidate_length)
                break

        if chosen is None:
            if not sampled:
                raise RuntimeError("Length variation sampling failed unexpectedly")

            if history:
                chosen = max(
                    sampled,
                    key=lambda sample: min(abs(sample[1] - prior_length) for prior_length in history),
                )
            else:
                chosen = sampled[-1]

        _, chosen_length = chosen
        history.append(chosen_length)
        if len(history) > memory_size:
            del history[:-memory_size]

        return chosen

    @staticmethod
    def _load_sentence_structure_config() -> Dict:
        """Load centralized sentence structure config (cached)."""
        if PromptBuilder._sentence_structure_cache is None:
            import yaml

            config_path = os.path.join('shared', 'config', 'sentence_structure.yaml')
            if not os.path.exists(config_path):
                raise FileNotFoundError(
                    f"Sentence structure config not found at {config_path}. "
                    "Fail-fast architecture requires this file."
                )

            with open(config_path, 'r', encoding='utf-8') as file_handle:
                PromptBuilder._sentence_structure_cache = yaml.safe_load(file_handle)

            if not PromptBuilder._sentence_structure_cache:
                raise ValueError(f"Sentence structure config is empty: {config_path}")

            if not isinstance(PromptBuilder._sentence_structure_cache, dict):
                raise TypeError(
                    f"Sentence structure config must be a mapping: {config_path}"
                )

        return PromptBuilder._sentence_structure_cache
    
    @staticmethod
    def _get_technical_guidance(voice_params: Optional[Dict[str, float]], enrichment_params: Optional[Dict], component_type: str = "micro") -> str:
        """
        Returns technical guidance from profiles YAML file.
        
        Args:
            voice_params: Voice parameters (for jargon_removal)
            enrichment_params: Enrichment parameters (for technical_intensity)
            component_type: Component type for profile lookup
            
        Returns:
            Technical guidance string from profile
        """
        # Load profiles
        profiles = PromptBuilder._load_technical_profiles()
        
        # FAIL-FAST: No fallbacks permitted per .github/copilot-instructions.md
        if not profiles or 'profiles' not in profiles:
            raise FileNotFoundError(
                f"Technical profiles file not found or invalid at prompts/registry/technical_profiles.yaml. "
                f"This file is REQUIRED for all text generation. NO FALLBACKS permitted."
            )
        
        if component_type not in profiles['profiles']:
            # Component doesn't use technical profiles - return empty string (not a fallback)
            logger.debug(f"Component '{component_type}' does not use technical profiles (not in profiles YAML)")
            return ""
        
        component_profile = profiles['profiles'][component_type]
        
        # Calculate intensity level
        jargon_removal = voice_params.get('jargon_removal', 0.5) if voice_params else 0.5
        tech_intensity = enrichment_params.get('technical_intensity', 0.22) if enrichment_params else 0.22
        
        # Determine level: minimal, moderate, or detailed
        if jargon_removal > 0.7 or tech_intensity < 0.3:
            level = 'minimal'
        elif tech_intensity < 0.7:
            level = 'moderate'
        else:
            level = 'detailed'
        
        # Get guidance from profile - FAIL-FAST if missing
        technical_approach = component_profile.get('technical_approach', {})
        guidance = technical_approach.get(level, '')
        
        if not guidance:
            raise ValueError(
                f"No '{level}' technical guidance found for component '{component_type}'. "
                f"Profile exists but missing technical_approach.{level} entry. "
                f"Fix prompts/registry/technical_profiles.yaml. "
                f"NO FALLBACKS permitted."
            )
        
        logger.debug(f"Using {level} technical guidance for {component_type}")
        return guidance.strip()
    
    @staticmethod
    def _get_sentence_guidance(voice_params: Optional[Dict[str, float]], length: int, component_type: str = "micro") -> str:
        """
        Returns sentence structure guidance from rhythm profiles YAML file.
        
        Args:
            voice_params: Voice parameters (for rhythm_variation)
            length: Target content length in words
            component_type: Component type for profile lookup
            
        Returns:
            Sentence structure guidance string from profile
        """
        # Load profiles
        profiles = PromptBuilder._load_rhythm_profiles()
        
        # FAIL-FAST: No fallbacks permitted per .github/copilot-instructions.md
        if not profiles or 'profiles' not in profiles:
            raise FileNotFoundError(
                f"Rhythm profiles file not found or invalid at prompts/registry/rhythm_profiles.yaml. "
                f"This file is REQUIRED for all text generation. NO FALLBACKS permitted."
            )
        
        if component_type not in profiles['profiles']:
            # Component doesn't use rhythm profiles - return empty string (not a fallback)
            logger.debug(f"Component '{component_type}' does not use rhythm profiles (not in profiles YAML)")
            return ""
        
        component_profile = profiles['profiles'][component_type]
        
        # Calculate rhythm pattern level
        rhythm_variation = voice_params.get('sentence_rhythm_variation', 0.5) if voice_params else 0.5
        
        # Determine pattern: consistent or varied
        pattern = 'varied' if rhythm_variation > 0.7 else 'consistent'
        
        # Get guidance from profile
        rhythm_patterns = component_profile.get('rhythm_patterns', {})
        guidance = rhythm_patterns.get(pattern, '')
        
        if not guidance:
            raise ValueError(
                f"No '{pattern}' rhythm pattern for component '{component_type}'. "
                "Fix prompts/registry/rhythm_profiles.yaml. NO FALLBACKS permitted."
            )
        
        logger.debug(f"Using {pattern} rhythm pattern for {component_type} ({length} words)")
        return guidance.strip()

    @staticmethod
    def _build_voice_instruction(
        author: str,
        country: str,
        esl_traits: str,
        voice: Optional[Dict],
        voice_params: Optional[Dict[str, float]],
        length: int,
        component_type: str
    ) -> str:
        """
        Build complete voice instruction section from persona data.
        
        This extracts voice instructions from persona files and formats them
        for injection into domain prompt templates via {voice_instruction} placeholder.
        
        Args:
            author: Author name
            country: Author country
            esl_traits: ESL linguistic patterns
            voice: Full voice/persona dict (MANDATORY - must not be None)
            voice_params: Voice parameters (intensity, rhythm, etc.)
            length: Target word count
            
        Returns:
            Formatted voice instruction string
            
        Raises:
            ValueError: If voice dict is None or empty (fail-fast requirement)
        """
        # MANDATORY: Voice instructions must be present for all text generation
        if not voice:
            raise ValueError(
                f"Voice instructions are MANDATORY for all text generation. "
                f"Author '{author}' from '{country}' has no voice/persona data loaded. "
                f"Check that persona file exists in shared/voice/profiles/"
            )
        
        # VOICE INSTRUCTION CENTRALIZATION POLICY:
        # Voice instructions ONLY exist in shared/voice/profiles/*.yaml
        # They are injected directly into domain prompts via {voice_instruction} placeholder
        # Humanness layer provides structural variation only (separate concern)
        
        # Extract voice instructions from persona
        use_compact = PromptBuilder._should_use_compact_voice(component_type)
        if use_compact:
            core_voice = voice.get('compact_voice_instruction', '')
            tonal_restraint = voice.get('compact_tonal_restraint', '')
            compliance_note = (
                "Voice compliance: apply the traits above consistently while keeping phrasing compact."
            )
            if not isinstance(core_voice, str) or not core_voice.strip():
                raise ValueError(
                    f"Compact voice instructions missing for '{author}' (component '{component_type}'). "
                    "Add compact_voice_instruction to the persona file."
                )
        else:
            core_voice = voice.get('core_voice_instruction', '')
            tonal_restraint = voice.get('tonal_restraint', '')
            compliance_note = (
                "You MUST write as {author} from {country} using the EXACT linguistic patterns specified above. "
                "This is not optional—your writing must demonstrate the specific EFL traits, sentence structures, "
                "vocabulary choices, and grammatical patterns detailed for your nationality. Generic technical "
                "English is unacceptable.\n\n"
                "CRITICALLY: Use the specific voice patterns from your profile (cleft structures, preposition "
                "extensions, phrasal verbs, article omission, temporal markers, etc.) throughout—at least 1-2 "
                "distinctive markers per paragraph as specified in your voice instructions."
            ).format(author=author, country=country)
        forbidden = voice.get('forbidden_phrases', [])
        
        voice_section = f"""AUTHOR: {author} from {country}

VOICE INSTRUCTIONS (from shared/voice/profiles/{author.lower().replace(' ', '_').replace(',', '').replace('.', '')}.yaml):
{core_voice}"""
        
        if tonal_restraint:
            voice_section += f"\n\n{tonal_restraint}"
        
        if forbidden:
            forbidden_str = "\n".join([f"  - {phrase}" for phrase in forbidden])
            voice_section += f"\n\n**FORBIDDEN PHRASES** (never use these):\n{forbidden_str}"
        
        # GLOBAL VOICE ENFORCEMENT (applies to all domains automatically)
        # Generic technical English is unacceptable
        # at least 1-2 distinctive markers per paragraph
        voice_section += f"""\n\n🔥 VOICE COMPLIANCE REQUIREMENT (MANDATORY):
    {compliance_note}"""
        
        # NO voice instruction duplication - violates Voice Instruction Centralization Policy
        # Humanness layer will inject full persona through {voice_instruction} placeholder
        
        return voice_section

    @staticmethod
    def _load_prompt_compaction_config() -> Dict:
        """Load prompt compaction config from generation/config.yaml (cached)."""
        if PromptBuilder._prompt_compaction_cache is None:
            from generation.config.config_loader import get_config

            config = get_config().config
            compaction = config.get('prompt_compaction')
            if not isinstance(compaction, dict):
                raise KeyError("Missing required config block: prompt_compaction")
            components = compaction.get('compact_voice_components')
            if not isinstance(components, list) or not components:
                raise KeyError(
                    "Missing required config key: prompt_compaction.compact_voice_components"
                )
            PromptBuilder._prompt_compaction_cache = {
                'compact_voice_components': components
            }

        return PromptBuilder._prompt_compaction_cache

    @staticmethod
    def _should_use_compact_voice(component_type: str) -> bool:
        compaction = PromptBuilder._load_prompt_compaction_config()
        components = compaction.get('compact_voice_components', [])
        return component_type in components

    @staticmethod
    def _load_component_template(component_type: str, domain: str) -> Optional[str]:
        """
        Load component-specific prompt template from section_display_schema.yaml.
        
        SCHEMA-ONLY APPROACH:
        Source: data/schemas/section_display_schema.yaml (REQUIRED)
        Loads from sections.{component_type}.prompt field
        
        Args:
            component_type: Component type (contaminatedBy, healthEffects, etc.)
            domain: Domain name (materials, contaminants, settings)
            
        Returns:
            Template string or None if not found in schema
            
        Raises:
            FileNotFoundError: If schema doesn't exist or can't be loaded
        """
        if not domain:
            raise ValueError("Domain is required to load component templates")

        try:
            prompt_text = PromptRegistryService.get_schema_prompt(
                domain=domain,
                component_type=component_type,
                include_descriptor=False,
            )
            if prompt_text:
                logger.debug(f"✅ Loaded prompt from schema registry service: {domain}.{component_type}")
                return prompt_text.strip()

            logger.debug(f"Component not in schema: {domain}.{component_type}")
            return None
        except Exception as e:
            logger.error(f"Failed to load section prompt for {domain}.{component_type}: {e}")
            raise FileNotFoundError(
                "Could not load section prompt via PromptRegistryService. "
                f"Domain: {domain}, component: {component_type}, error: {e}"
            )
    
    @staticmethod
    def build(context: 'PromptContext', **kwargs) -> str:
        """
        Build prompt using PromptContext object (NEW unified interface).
        
        This is the preferred method for new code. Extracts parameters from
        PromptContext and delegates to build_unified_prompt().
        
        Args:
            context: PromptContext object with all generation parameters
            **kwargs: Additional parameters to override context values
            
        Returns:
            Complete prompt string
            
        Example:
            >>> from shared.text.prompt_context import PromptContext
            >>> context = PromptContext(
            ...     topic="Aluminum",
            ...     voice=voice_dict,
            ...     length=50,
            ...     component_type="description",
            ...     domain="materials"
            ... )
            >>> prompt = PromptBuilder.build(context)
        """
        # Extract parameters from context
        params = {
            'topic': context.topic,
            'voice': context.voice,
            'length': context.length,
            'component_type': context.component_type,
            'domain': context.domain,
            'facts': context.facts or "",
            'context': context.context or "",
            'voice_params': context.voice_params,
            'enrichment_params': context.enrichment_params,
            'variation_seed': context.variation_seed,
            'humanness_layer': context.humanness_layer,
            'faq_count': context.faq_count,
            'item_data': context.item_data,
            'opening_style': getattr(context, 'opening_style', None),
            'variation_pattern': getattr(context, 'variation_pattern', None),
        }
        
        # Allow kwargs to override context values
        params.update(kwargs)
        
        return PromptBuilder.build_unified_prompt(**params)
    
    @staticmethod
    def build_unified_prompt(
        topic: str,  # Renamed from 'material' for generality
        voice: Dict,
        length: Optional[int] = None,
        facts: str = "",
        context: str = "",
        component_type: str = "micro",
        domain: str = "materials",
        voice_params: Optional[Dict[str, float]] = None,  # NEW: Voice parameters from config
        enrichment_params: Optional[Dict] = None,  # Phase 3+: Technical intensity control
        variation_seed: Optional[int] = None,
        humanness_layer: Optional[str] = None,  # NEW: Universal Humanness Layer instructions
        faq_count: Optional[int] = None,  # For FAQ generation
        item_data: Optional[Dict] = None,  # NEW: Full item data for template placeholders
        opening_style: Optional[str] = None,
        variation_pattern: Optional[str] = None,
    ) -> str:
        """
        Build unified prompt combining all elements.
        
        Args:
            topic: Subject matter (material name, historical event, recipe, etc.)
            voice: Voice profile dict
            length: Target word count (uses component default if None)
            facts: Formatted facts string
            context: Additional domain-specific context
            component_type: Type of content (micro, description, faq, etc.)
            domain: Content domain (materials, history, recipes, etc.)
            variation_seed: Optional seed for variation (defeats caching)
            humanness_layer: Dynamic humanness instructions from HumannessOptimizer (NEW)
            item_data: Full item data dict for extracting template placeholders (NEW)
            
        Returns:
            Complete prompt string
        """
        # Get component specification (fail-fast)
        spec = ComponentRegistry.get_spec(component_type)

        # Get domain context (fail-fast)
        domain_ctx = DomainContext.get_domain(domain)

        text_field_config = PromptBuilder._load_text_field_config()
        resolved_base_length = PromptBuilder._resolve_base_length(
            text_field_config=text_field_config,
            component_type=component_type,
            fallback_length=spec.default_length,
        )
        
        # Use component default length if not specified
        if length is None:
            length = resolved_base_length
        
        # SINGLE SOURCE OF TRUTH: Length variation calculated here ONLY.
        # Use call-provided seed when present (for traceability); otherwise use fresh entropy.
        if variation_seed is None:
            variation_seed = random.SystemRandom().randint(0, 2**31 - 1)

        rng = random.Random(variation_seed)
        randomization_cfg = text_field_config.get('randomization_range')
        if not isinstance(randomization_cfg, dict):
            raise ValueError(
                "Missing required config block: randomization_range in generation/text_field_config.yaml"
            )

        factor_min, factor_max = PromptBuilder._resolve_pattern_factor_range(
            text_field_config=text_field_config,
            randomization_cfg=randomization_cfg,
            variation_pattern=variation_pattern,
        )
        factor_min, factor_max = PromptBuilder._resolve_field_factor_override(
            text_field_config=text_field_config,
            component_type=component_type,
            factor_min=factor_min,
            factor_max=factor_max,
        )
        variation_instruction = PromptBuilder._resolve_variation_instruction(
            text_field_config=text_field_config,
            variation_pattern=variation_pattern,
        )

        variation_factor, length = PromptBuilder._select_variation_factor_with_memory(
            domain=domain,
            component_type=component_type,
            base_length=length,
            rng=rng,
            factor_min=factor_min,
            factor_max=factor_max,
        )
        logger.info(
            f"📏 Length variation: {length} words (base × {variation_factor:.2f}, "
            f"seed={variation_seed}, pattern={variation_pattern or 'random'})"
        )
        
        # Extract voice characteristics
        country = voice.get('country', 'USA')
        author = voice.get('author', 'Expert')
        
        linguistic = voice.get('linguistic_characteristics', {})
        sentence_patterns = linguistic.get('sentence_structure', {}).get('patterns', [])
        esl_traits = "; ".join(sentence_patterns[:2]) if sentence_patterns else "Natural regional patterns"
        
        # Extract sentence style guidance from shared config + voice profile
        # NEW LOCATION: voice.sentence_structure.{component_type}
        sentence_config = PromptBuilder._load_sentence_structure_config()
        shared_sentence_structure = sentence_config.get('components')
        if not isinstance(shared_sentence_structure, dict):
            raise TypeError(
                "shared/config/sentence_structure.yaml must contain 'components' mapping"
            )

        sentence_structure = dict(shared_sentence_structure)
        voice_sentence_structure = voice.get('sentence_structure', {})
        if voice_sentence_structure:
            if not isinstance(voice_sentence_structure, dict):
                raise TypeError("voice.sentence_structure must be a dictionary when provided")
            sentence_structure.update(voice_sentence_structure)
        sentence_key_candidates = [component_type]
        if component_type in ('pageDescription', 'page_description'):
            sentence_key_candidates.append('description')
        if component_type == 'caption':
            sentence_key_candidates.append('micro')

        sentence_style = ''
        for key in sentence_key_candidates:
            value = sentence_structure.get(key, '')
            if value:
                sentence_style = value
                break

        if not sentence_style:
            generation_constraints = voice.get('generation_constraints', {})
            if not isinstance(generation_constraints, dict):
                raise TypeError("voice.generation_constraints must be a dictionary when provided")

            constraint_aliases = []
            if component_type in ('pageDescription', 'page_description', 'description'):
                constraint_aliases.append('text')
            if component_type in ('micro', 'caption'):
                constraint_aliases.append('micro')
            if component_type == 'faq':
                constraint_aliases.append('faq')

            for key in constraint_aliases:
                constraint_value = generation_constraints.get(key)
                if constraint_value:
                    if isinstance(constraint_value, dict):
                        parts = [f"{k}={v}" for k, v in constraint_value.items()]
                        sentence_style = f"Use {key} sentence style constraints: " + ", ".join(parts)
                    else:
                        sentence_style = f"Use {key} sentence style constraints: {constraint_value}"
                    break
        
        if not sentence_style:
            raise ValueError(
                f"Missing sentence_structure for component '{component_type}' in voice profile. "
                "Fail-fast architecture requires explicit component sentence style."
            )
        
        return PromptBuilder._build_spec_driven_prompt(
            topic=topic,
            author=author,
            country=country,
            esl_traits=esl_traits,
            sentence_style=sentence_style,
            length=length,
            facts=facts,
            context=context,
            spec=spec,
            domain_ctx=domain_ctx,
            resolved_base_length=resolved_base_length,
            voice_params=voice_params,  # NEW: Pass to spec builder
            enrichment_params=enrichment_params,  # Phase 3+: Technical intensity
            variation_seed=variation_seed,
            voice=voice,  # NEW: Pass full voice profile for grammar_norms access
            humanness_layer=humanness_layer,  # NEW: Universal Humanness Layer
            faq_count=faq_count,  # Pass FAQ count
            item_data=item_data,  # NEW: Pass item_data for template placeholders
            opening_style=opening_style,
            variation_pattern=variation_pattern,
            variation_instruction=variation_instruction,
        )
    
    @staticmethod
    def _build_spec_driven_prompt(
        topic: str,
        author: str,
        country: str,
        esl_traits: str,
        sentence_style: str,
        length: int,
        facts: str,
        context: str,
        spec,  # ComponentSpec
        domain_ctx,  # DomainContext
        resolved_base_length: int,
        voice_params: Optional[Dict[str, float]] = None,  # NEW: Voice parameters
        enrichment_params: Optional[Dict] = None,  # Phase 3+: Technical intensity
        variation_seed: Optional[int] = None,
        voice: Optional[Dict] = None,  # NEW: Full voice profile for grammar_norms access
        humanness_layer: Optional[str] = None,  # NEW: Universal Humanness Layer
        faq_count: Optional[int] = None,  # For FAQ generation
        item_data: Optional[Dict] = None,  # NEW: Full item data for template placeholders
        opening_style: Optional[str] = None,
        variation_pattern: Optional[str] = None,
        variation_instruction: Optional[str] = None,
    ) -> str:
        """
        Build prompt using component specification and domain context.
        
        This is the new flexible approach that works for any component type
        and content domain without hardcoding templates.
        
        Args:
            humanness_layer: Dynamic humanness instructions from HumannessOptimizer
        """
        # Build context section based on domain
        # NO EXAMPLES - facts come from actual data only
        facts_section = f"FACTUAL INFORMATION:\n{facts}" if facts else ""
        context_section = f"""TOPIC: {topic} ({domain_ctx.domain})

{facts_section}

DOMAIN GUIDANCE: {domain_ctx.focus_template}""".strip()

        if context:
            context_section += f"\n\nADDITIONAL CONTEXT:\n{context}"
        
        # Build voice_instruction FIRST (before template formatting)
        # This needs to be built early so it can be injected into component templates
        voice_instruction = PromptBuilder._build_voice_instruction(
            author=author,
            country=country,
            esl_traits=esl_traits,
            voice=voice,
            voice_params=voice_params,
            length=length,
            component_type=spec.name
        )
        
        # Load component-specific template if available (domain-specific first)
        component_context = ""
        component_template = PromptBuilder._load_component_template(spec.name, domain_ctx.domain)
        voice_injected_via_template = False
        if component_template:
            # NEW: Build dynamic guidance sections based on config
            technical_guidance = PromptBuilder._get_technical_guidance(
                voice_params=voice_params,
                enrichment_params=enrichment_params,
                component_type=spec.name
            )
            
            sentence_guidance = PromptBuilder._get_sentence_guidance(
                voice_params=voice_params,
                length=length,
                component_type=spec.name
            )
            
            # Replace placeholders in template
            # Set default FAQ count if not provided
            if faq_count is None:
                faq_count = 3  # Default FAQ count
            
            # Build template parameters dict with all possible placeholders
            # CRITICAL: These are OPTIONAL placeholders for cross-domain compatibility.
            # Templates that use placeholders not listed here MUST provide them via facts/context.
            # Empty strings allow templates to use {placeholder} without KeyError IF the value is optional.
            
            # Extract from item_data if provided, otherwise use defaults/empty
            item_data = item_data or {}
            prompt_subject = PromptBuilder._strip_subject_suffix_for_prompt(topic=topic, domain=domain_ctx.domain)
            prompt_category = PromptBuilder._resolve_prompt_category(item_data=item_data, domain=domain_ctx.domain)
            
            template_params = {
                'author': author,
                'author_name': author,  # Alias for postprocess templates
                'author_country': country,  # Explicit country for postprocess
                'subject': prompt_subject,
                'material': topic,
                'material_name': topic,  # Alias for postprocess templates
                'identifier': topic,  # Generic identifier
                'contaminant': topic,  # For contaminants domain
                'contaminant_name': topic,  # Alias for contaminants
                'country': country,
                'length': length,
                'technical_guidance': technical_guidance,
                'sentence_guidance': sentence_guidance,
                'facts': facts,
                'properties': facts,  # Alias - properties are in facts
                'context': domain_ctx.domain,
                'faq_count': faq_count,
                'voice_instruction': voice_instruction,  # CRITICAL: Must be present
                # Extract from item_data (postprocess and domain-specific)
                'category': prompt_category,
                'subcategory': item_data.get('subcategory', ''),
                'context_notes': item_data.get('context_notes', ''),
                'description': item_data.get('description', ''),
                'machine_settings': item_data.get('machine_settings', ''),
                'challenges': item_data.get('challenges', ''),
                'existing_content': item_data.get('existing_content', ''),  # For postprocess templates
                'valid_materials': ', '.join(item_data.get('valid_materials', []))  # For contaminants cross-linking
            }
            
            # FAIL-FAST: No try/except fallback. If template requires a placeholder not in
            # template_params, generation MUST fail with KeyError.
            component_context = component_template.format(**template_params)
            voice_injected_via_template = '{voice_instruction}' in component_template
            # Template contains all content instructions (focus, format, style)
            context_section = f"""{component_context}

{context_section}"""

        # Ensure voice instructions are ALWAYS present (centralized source of truth).
        # If a component template omits {voice_instruction}, inject the rendered persona block here.
        if not voice_injected_via_template:
            context_section = f"""{context_section}

VOICE INSTRUCTIONS:
{voice_instruction}"""

        shared_text_prompt_core = PromptBuilder._load_shared_text_prompt_core()
        
        # Build requirements section with dynamic sentence structure guidance
        # Override terminology based on technical_intensity (0.0-1.0 normalized)
        tech_intensity = enrichment_params.get('technical_intensity', 0.22) if enrichment_params else 0.22
        
        if tech_intensity < 0.15:  # Very low (slider 1-2)
            # Level 1: Override to prevent any specs
            terminology = "Qualitative descriptions only; NO numbers, units, or measurements"
        else:
            # Level 2-10: Use domain default
            terminology = domain_ctx.terminology_style
        
        # Length instructions come from templates or injected requirements below
        # to avoid missing WORD LENGTH guidance in prompts.
        requirements = [
            f"- Terminology: {terminology}"
        ]

        if not PromptBuilder._has_word_length_spec(
            component_context,
            shared_text_prompt_core,
            humanness_layer or ""
        ):
            length_instruction = PromptBuilder._build_length_instruction(
                component_type=spec.name,
                base_length=length,
                faq_count=faq_count
            )
            requirements.append(f"- {length_instruction}")
        
        # Phase 3+: Add CRITICAL technical language requirement based on enrichment_params
        if enrichment_params:
            tech_intensity = enrichment_params.get('technical_intensity', 0.22)  # 0.0-1.0 normalized
            if tech_intensity < 0.15:  # Very low (slider 1-2)
                # Level 1: NO technical specs at all - REINFORCE THIS MULTIPLE TIMES
                requirements.append("\n🚫 CRITICAL REQUIREMENT - TECHNICAL LANGUAGE:")
                requirements.append("- ABSOLUTELY NO technical specifications, measurements, numbers with units, or property values")
                requirements.append("- Examples of FORBIDDEN content: '1941 K', '8.8 g/cm³', '500 J/kg·K', '19.3 g/cm³', '110 GPa', '400 MPa', '41,000,000 S/m'")
                requirements.append("- ONLY use qualitative descriptions: 'heat-resistant', 'dense', 'strong', 'conductive', 'durable'")
                requirements.append("- Focus on benefits, applications, and characteristics WITHOUT precise values")
                requirements.append("- ⚠️ THIS OVERRIDES ALL OTHER INSTRUCTIONS - NO EXCEPTIONS")
            elif tech_intensity < 0.5:  # Low-medium (slider 3-5)
                # Level 2: Minimal specs (1-2 max)
                requirements.append("\n⚠️ TECHNICAL LANGUAGE: Minimal specs only (1-2 max, prefer conceptual)")
            # High (slider 6-10): Allow 3-5 specs (no restriction needed)
        
        # NOTE: Emotional tone controlled by base.txt system template and persona files
        # Dynamic emotional_tone parameter removed per Option A architecture decision
        
        if not spec.end_punctuation:
            requirements.append("- NO period at end")

        if opening_style:
            requirements.append(
                f"- Opening style: {opening_style}. Start with this style and avoid repeating openings across fields."
            )

        if variation_pattern:
            requirements.append(
                f"- Variation mode ({variation_pattern}): {variation_instruction or 'Adjust pacing and detail to match this mode.'}"
            )

        # PageDescription-specific phrase guardrails to reduce repeated quality failures.
        if spec.name == 'pageDescription':
            requirements.append("- Do NOT use these phrases: 'stands out', 'in practice', 'presents a challenge', 'critical pitfall'")
            requirements.append("- Use direct, concrete phrasing without transition clichés")
        
        requirements_section = "\n".join(requirements)
        
        # Voice section already built via voice_instruction at line 406
        # and injected into component template via {voice_instruction} placeholder
        # NO DUPLICATION - voice appears only once in final prompt
        
        # Phase 3+: Technical language guidance moved to REQUIREMENTS section for higher priority
        
        # Phase 3B: Anti-AI rules are now in base.txt system template
        # The humanness_layer already contains comprehensive anti-AI guidance
        # This section is kept minimal to avoid prompt bloat
        anti_ai = ""  # Rules consolidated into base.txt and humanness_layer
        
        # Component-specific enrichment hints are in prompt templates
        # NO content instructions in code - see Content Instruction Policy
        enrichment_hints = ""
        
        # Add variation seed to defeat caching (if provided)
        variation_note = ""
        if variation_seed is not None:
            variation_note = f"\n\n[Generation ID: {variation_seed} - ignore this, just for tracking]"
        
        # Inject Universal Humanness Layer (between context and requirements)
        humanness_section = ""
        if humanness_layer:
            humanness_section = f"\n\n{humanness_layer}\n"
        
        # Schema-based components require explicit OUTPUT FORMAT
        # List of schema-based components that use title/description structure
        schema_components = {
            'contaminatedBy', 'relatedMaterials', 'materialCharacteristics',
            'laserMaterialInteraction', 'physicalProperties', 'appearanceVariations',
            'healthEffects', 'exposureLimits', 'ppeRequirements', 'emergencyResponse',
            'storageRequirements', 'regulatoryStandards', 'regulatoryClassification',
            'industryApplications', 'commonChallenges', 'detectionMethods',
            'preventionStrategies', 'removalMethods', 'environmentalImpact',
            'continuousMonitoring', 'reactivity', 'producedByMaterials',
            'producedFromContaminants', 'relatedContaminants', 'relatedCompounds'
        }
        
        output_format_section = ""
        if spec.name in schema_components:
            output_format_section = """

    OUTPUT FORMAT:
Title: [Write a 3-5 word concise title here]

Description: [Write the full description here]

    Use exactly two labeled lines. The first line must start with "Title:" and the second line must start with "Description:"."""
        
        # Assemble complete prompt
        # NOTE: Voice instructions already in context_section via {voice_instruction} placeholder
        # No generic "be unique" override that negates specific voice rules
        # NOTE: Template already includes author context - no "You are" prefix needed
        prompt = f"""{context_section}

    SHARED CORE GUIDANCE:
    {shared_text_prompt_core}
{humanness_section}
REQUIREMENTS:
{requirements_section}
{output_format_section}

{anti_ai}{enrichment_hints}{variation_note}

Generate {spec.name} for {topic}:"""
        
        return prompt
    
    # Legacy method - kept for backward compatibility
    # Component-specific prompt methods REMOVED (November 18, 2025)
    # All content instructions now ONLY in prompts/*.txt templates
    # Use _load_prompt_template(component_type) for generic template loading
    # See: Component Discovery Policy + Content Instruction Policy
    
    @staticmethod
    def _build_generic_prompt(
        material: str,
        author: str,
        country: str,
        esl_traits: str,
        length: int,
        facts: str,
        context: str
    ) -> str:
        """Build generic content prompt"""
        return f"""You are {author}, a technical writer from {country}, writing about {material}.

MATERIAL INFORMATION:
{facts}

ADDITIONAL CONTEXT:
{context}

VOICE CHARACTERISTICS:
- {esl_traits}
- Length: Aim for natural expression (length will vary naturally)
- Mix technical and accessible language
- Natural flow with varied sentence structures
- Subtle regional flavor
- Occasional minor imperfections (natural for ESL)

Write factual, grounded content. Avoid AI-like uniformity. Be human.

Generate text:"""
    
    @staticmethod
    def adjust_on_failure(prompt: str, failure_reason: str, attempt: int) -> str:
        """
        Dynamically adjust prompt based on detection failure.
        
        Args:
            prompt: Original prompt
            failure_reason: Why detection failed
            attempt: Attempt number
            
        Returns:
            Modified prompt
        """
        adjustments = []
        
        if "too uniform" in failure_reason or "repetitive" in failure_reason or attempt > 1:
            adjustments.append("🚨 CRITICAL - OUTPUT TOO UNIFORM:")
            adjustments.append("- Start with a COMPLETELY different approach (question? comparison? surprising fact?)")
            adjustments.append("- Avoid leading with material name + technical specs")
            adjustments.append("- Try: benefit-first, application-first, or problem-solution structure")
            adjustments.append("- Mix sentence lengths: one short (5 words), one medium (10-12), one longer")
        
        if "ai score" in failure_reason or "formulaic" in failure_reason or attempt > 2:
            adjustments.append("🚨 AI PATTERNS DETECTED:")
            adjustments.append("- BANNED phrases: 'enables', 'facilitates', 'leverages', 'demonstrates', 'provides'")
            adjustments.append("- BANNED structure: 'X with Y property for Z application'")
            adjustments.append("- ADD conversational connectors: 'though', 'but', 'yet', 'while'")
            adjustments.append("- USE approximations: 'around', 'roughly', 'nearly', 'about'")
            adjustments.append("- INCLUDE qualitative: 'lightweight yet strong', 'surprisingly durable'")
            adjustments.append("- TRY unexpected opening: Don't start with the obvious")
        
        if attempt >= 3:
            adjustments.append("🔥 FINAL ATTEMPT - MAXIMUM VARIATION:")
            adjustments.append("- Completely break from previous patterns")
            adjustments.append("- Use fragment sentences if natural")
            adjustments.append("- Add rhetorical elements")
            adjustments.append("- Consider contrarian or unexpected angle")
            adjustments.append("- Prioritize readability over technical precision")
        
        if adjustments:
            return prompt + "\n\n" + "\n".join(adjustments) + "\n"
        
        return prompt
