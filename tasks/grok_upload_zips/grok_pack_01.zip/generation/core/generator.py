"""
Simple Generator - Single-Pass Content Generation

Clean, focused generator for the generation phase:
- ONE API call per material
- Single-pass generation (no automatic retries)
- Save directly to Materials.yaml with atomic writes
- Quality validation happens after save

Architecture:
    Generation Phase: Generate → Evaluate → Save → Learn (single-pass)
    Learning Phase: Analyze patterns, update recommendations (discrete)
    
Note: No automatic retry loop. Manual re-run required if quality insufficient.
Quality gates (Winston AI, Subjective Eval, Realism) provide feedback for learning
but do not trigger automatic regeneration.

Design Principles:
- Fail fast with clear error messages
- No fallbacks or defaults that hide problems
- Atomic file operations (never corrupt Materials.yaml)
- Simple, linear flow with explicit error handling
"""

import logging
import os
import random
import re
from pathlib import Path
from typing import Any, Dict, Optional

from shared.utils.yaml_utils import load_yaml

logger = logging.getLogger(__name__)


class Generator:
    """
    Single-pass generator for content creation.
    
    Responsibilities:
    - Load material data
    - Build prompt with facts
    - Make ONE API call
    - Save result to Materials.yaml
    
    Does NOT handle:
    - Quality validation (post-processing)
    - Retry loops (post-processing)
    - Learning feedback (post-processing)
    """
    
    def __init__(self, api_client, domain: str = 'materials', adapter=None):
        """
        Initialize generator for any domain.
        
        Args:
            api_client: API client for content generation (required)
            domain: Domain name (e.g., 'materials', 'settings') - determines config
            adapter: Optional pre-configured adapter (overrides domain parameter)
        """
        if not api_client:
            raise ValueError("API client required for content generation")
        
        self.api_client = api_client
        self._last_variation_seed = None
        self.domain = domain
        self.logger = logging.getLogger(__name__)
        
        # Initialize adapter - use DomainAdapter for config-driven behavior
        if adapter is None:
            from generation.core.adapters.domain_adapter import DomainAdapter
            self.adapter = DomainAdapter(domain)
        else:
            self.adapter = adapter
        
        # Initialize data provider for real facts
        from generation.context.data_provider import DataProvider
        self.data_provider = DataProvider()
        
        # Initialize research capabilities (NEW - Dec 11, 2025)
        from shared.text.research import SystemDataResearcher
        self.researcher = SystemDataResearcher()
        
        # Load config for base parameters
        from generation.config.config_loader import get_config
        config = get_config()
        self.processing_config = config
        self.config = config.config
        
        # Dynamic config for parameter baseline
        from generation.config.dynamic_config import DynamicConfig
        self.dynamic_config = DynamicConfig()
        
        # Load personas
        self.personas = self._load_all_personas()
        
        # Humanness cache (session-level to avoid regenerating for each field)
        self._humanness_cache = {}
        self._opening_style_usage = {}
        self._variation_pattern_usage = {}
        self._variation_pattern_bank = None
        
        self.logger.info(f"Generator initialized for '{domain}' domain (single-pass with research)")
    
    def _load_all_personas(self) -> Dict[int, Dict[str, Any]]:
        """Load all author voice profiles from shared/voice/profiles/."""
        personas = {}
        
        # Canonical voice source per policy
        personas_dir = Path("shared/voice/profiles")
        if not personas_dir.exists():
            raise FileNotFoundError(f"Voice profiles directory not found: {personas_dir}")
        
        for persona_file in personas_dir.glob("*.yaml"):
            persona_data = load_yaml(persona_file)
            author_id = persona_data.get('id')  # Changed from 'author_id' to 'id'
            if author_id:
                personas[author_id] = persona_data
        
        self.logger.info(f"Loaded {len(personas)} personas")
        return personas

    def _get_domain_generation_list(self, *path_parts: str) -> list:
        from generation.config.config_loader import get_config

        config = get_config().config
        domain_generation = config.get('domain_generation')
        if not isinstance(domain_generation, dict):
            raise KeyError("Missing required config block: domain_generation")
        if self.domain not in domain_generation:
            raise KeyError(
                f"Missing domain_generation config for domain '{self.domain}'"
            )
        node: Any = domain_generation[self.domain]

        for part in path_parts:
            if not isinstance(node, dict) or part not in node:
                raise KeyError(
                    f"Missing required config key: domain_generation.{self.domain}.{'.'.join(path_parts)}"
                )
            node = node[part]

        if not isinstance(node, list):
            raise TypeError(
                f"domain_generation.{self.domain}.{'.'.join(path_parts)} must be a list"
            )
        return node
    
    def _get_persona_by_author_id(self, author_id: int) -> Dict[str, Any]:
        """Get persona by author ID"""
        if author_id not in self.personas:
            raise ValueError(f"Persona not found for author_id {author_id}")
        return self.personas[author_id]
    
    def _load_data(self) -> Dict:
        """Load data using domain adapter"""
        return self.adapter.load_all_data()
    
    def _get_item_data(self, identifier: str) -> Dict:
        """Get item data using domain adapter"""
        return self.adapter.get_item_data(identifier)
    
    def _build_context(self, item_data: Dict) -> str:
        """Build context using domain adapter"""
        return self.adapter.build_context(item_data)
    
    def _get_dynamic_config_for_author(self, author_id: int):
        """Build DynamicConfig using author-specific intensity configuration."""
        from generation.config.author_config_loader import get_author_config
        from generation.config.dynamic_config import DynamicConfig

        author_processing_config = get_author_config(author_id)
        return DynamicConfig(base_config=author_processing_config)

    def _get_base_parameters(self, component_type: str, dynamic_config=None) -> Dict[str, Any]:
        """Get base generation parameters from dynamic config"""
        active_dynamic_config = dynamic_config if dynamic_config is not None else self.dynamic_config

        penalties = active_dynamic_config.calculate_penalties(component_type)
        if 'frequency_penalty' not in penalties:
            raise KeyError("Dynamic penalties missing required key: frequency_penalty")
        if 'presence_penalty' not in penalties:
            raise KeyError("Dynamic penalties missing required key: presence_penalty")

        return {
            'temperature': active_dynamic_config.calculate_temperature(),
            'max_tokens': active_dynamic_config.calculate_max_tokens(component_type),
            'api_penalties': penalties,
        }

    def _should_apply_opening_style(self, component_type: str) -> bool:
        if component_type.endswith("Title"):
            return False
        if component_type in {"faq"}:
            return False
        return True

    def _select_opening_style(self, identifier: str, component_type: str) -> Optional[str]:
        if not self._should_apply_opening_style(component_type):
            return None

        from shared.text.utils.prompt_registry_service import PromptRegistryService

        styles = PromptRegistryService.get_opening_style_bank()
        used = self._opening_style_usage.setdefault(identifier, [])

        available = [style for style in styles if style not in used]
        if not available:
            available = [style for style in styles if style != used[-1]] if used else styles

        chosen = random.SystemRandom().choice(available)
        used.append(chosen)
        return chosen

    def _should_apply_variation_pattern(self, component_type: str) -> bool:
        if component_type.endswith("Title"):
            return False
        return component_type not in {"faq"}

    def _get_variation_pattern_bank(self) -> list[str]:
        if self._variation_pattern_bank is None:
            config = load_yaml(Path("generation") / "text_field_config.yaml")
            variation_patterns = config.get("variation_patterns")
            if not isinstance(variation_patterns, dict):
                raise ValueError(
                    "Missing required config block: variation_patterns in generation/text_field_config.yaml"
                )

            bank = variation_patterns.get("bank")
            if not isinstance(bank, list) or not bank:
                raise ValueError(
                    "variation_patterns.bank must be a non-empty list in generation/text_field_config.yaml"
                )

            normalized = []
            for pattern in bank:
                if not isinstance(pattern, str) or not pattern.strip():
                    raise ValueError("variation_patterns.bank entries must be non-empty strings")
                normalized.append(pattern.strip())

            self._variation_pattern_bank = normalized

        return self._variation_pattern_bank

    def _select_variation_pattern(self, component_type: str) -> Optional[str]:
        if not self._should_apply_variation_pattern(component_type):
            return None

        bank = self._get_variation_pattern_bank()
        state = self._variation_pattern_usage.setdefault(
            self.domain,
            {
                "remaining": [],
                "last": None,
            },
        )

        remaining = state["remaining"]
        if not remaining:
            remaining.extend(bank)
            random.SystemRandom().shuffle(remaining)

            last_pattern = state.get("last")
            if last_pattern and len(remaining) > 1 and remaining[0] == last_pattern:
                for index in range(1, len(remaining)):
                    if remaining[index] != last_pattern:
                        remaining[0], remaining[index] = remaining[index], remaining[0]
                        break

        chosen = remaining.pop(0)
        state["last"] = chosen
        return chosen
    
    def generate(
        self,
        identifier: str,
        component_type: str,
        faq_count: int = None
    ) -> Dict[str, Any]:
        """
        Generate content with single API call AND save to domain data file.
        
        Args:
            identifier: Item name (material, setting, etc.) - domain agnostic
            component_type: Type of component (micro, description, faq)
            faq_count: Number of FAQ items (ignored for non-FAQ components)
            
        Returns:
            Dict with 'content', 'length', 'word_count', 'saved', 'temperature'
            
        Raises:
            ValueError: If identifier not found or generation fails
            FileNotFoundError: If required files missing
        """
        # Generate humanness layer (structural variation only - voice comes from persona)
        from learning.humanness_optimizer import HumannessOptimizer
        humanness_optimizer = HumannessOptimizer()
        
        # Get base word count target from validated config
        length_target = self.processing_config.get_component_length(component_type)
        
        humanness_layer = humanness_optimizer.generate_humanness_instructions(
            component_type=component_type,
            length_target=length_target
        )
        self.logger.info(f"🧠 Generated humanness layer ({len(humanness_layer)} chars)")
        
        result = self.generate_without_save(identifier, component_type, faq_count, humanness_layer)

        
        # Save using domain adapter (handles correct file path automatically)
        self.adapter.write_component(identifier, component_type, result['content'])
        self.logger.info(f"💾 Saved to {self.adapter.get_data_path()}")
        result['saved'] = True
        
        return result
    
    def generate_without_save(
        self,
        identifier: str,
        component_type: str,
        faq_count: int = None,
        humanness_layer: Optional[str] = None,
        **kwargs  # Accept existing_content and other postprocess params
    ) -> Dict[str, Any]:
        """
        Generate content WITHOUT saving.
        
        Used by QualityEvaluatedGenerator for single-pass generation
        with post-save quality evaluation for learning.
        
        Args:
            identifier: Item name (material, setting, etc.) - domain agnostic
            component_type: Type of component (micro, description, faq)
            faq_count: Number of FAQ items (ignored for non-FAQ components)
            humanness_layer: Dynamic humanness instructions (from HumannessOptimizer)
            **kwargs: Additional context (e.g., existing_content for postprocessing)
            
        Returns:
            Dict with 'content', 'length', 'word_count', 'saved'=False, 'temperature'
            
        Raises:
            ValueError: If identifier not found or generation fails
            FileNotFoundError: If required files missing
        """
        self.logger.info(f"\n🔄 GENERATION: {component_type} for {identifier} ({self.domain} domain)")

        skip_prompt_validation = bool(kwargs.pop('skip_prompt_validation', False))
        
        # Validate component type exists
        from shared.text.utils.component_specs import ComponentRegistry
        try:
            spec = ComponentRegistry.get_spec(component_type)
        except KeyError:
            raise ValueError(f"Unknown component type: {component_type}")
        
        # Load item data using domain adapter
        item_data = self._get_item_data(identifier)
        
        # Format with SEO-specific data if generating SEO components
        seo_components = self._get_domain_generation_list('seo_components')
        if component_type in seo_components:
            print(f"🔍 SEO component detected: {component_type}")
            self.logger.info(f"🔍 SEO component detected: {component_type}")
            from generation.context.seo_formatter import SEOContextFormatter
            try:
                seo_context = SEOContextFormatter.enrich_material_for_seo(item_data, identifier)
                # Merge SEO context into item_data
                item_data.update(seo_context)
                print(f"📊 Enriched with SEO context ({len(seo_context)} fields)")
                print(f"   Fields: {', '.join(sorted(seo_context.keys()))}")
                self.logger.info(f"📊 Enriched with SEO context ({len(seo_context)} fields)")
                self.logger.info(f"   Fields: {', '.join(sorted(seo_context.keys()))}")
            except Exception as e:
                print(f"❌ SEO enrichment failed: {e}")
                self.logger.error(f"❌ SEO enrichment failed: {e}")
                import traceback
                traceback.print_exc()
                raise
        
        # Merge any additional context from kwargs (e.g., existing_content for postprocessing)
        # CRITICAL: Don't overwrite item_data keys, only add missing ones
        for key, value in kwargs.items():
            if key not in item_data and value is not None:
                item_data[key] = value
        
        # Generate humanness layer if not provided (with item-aware session-level caching)
        if humanness_layer is None:
            cache_key = f"{identifier}:{component_type}"
            
            # Check cache first (avoid regenerating for the SAME item+field)
            if cache_key in self._humanness_cache:
                humanness_layer = self._humanness_cache[cache_key]
                print(f"♻️  Using cached humanness instructions ({len(humanness_layer)} chars)")
                self.logger.info(f"♻️  Using cached humanness layer from previous generation")
            else:
                from learning.humanness_optimizer import HumannessOptimizer
                humanness_optimizer = HumannessOptimizer()
                humanness_layer = humanness_optimizer.generate_humanness_instructions(
                    component_type=component_type
                )
                print(f"🧠 Generating humanness instructions...")
                self.logger.info(f"🧠 Generated humanness layer ({len(humanness_layer)} chars)")
                
                # Cache for subsequent fields in this session
                self._humanness_cache[cache_key] = humanness_layer
        
        # Get author ID using adapter (domain-agnostic)
        author_id = self.adapter.get_author_id(item_data)
        voice = self._get_persona_by_author_id(author_id)
        author_dynamic_config = self._get_dynamic_config_for_author(author_id)
        
        # Get facts and context (pass component_type for section-specific property selection)
        facts = self.data_provider.fetch_real_facts(identifier, component_type=component_type)
        context = self._build_context(item_data)

        voice_params = author_dynamic_config.calculate_voice_parameters()
        fact_enrichment_params = author_dynamic_config.calculate_enrichment_params()
        facts = self.data_provider.format_facts_for_prompt(
            facts,
            enrichment_params=fact_enrichment_params,
            voice_params=voice_params
        )
        
        # Get base parameters
        params = self._get_base_parameters(component_type, dynamic_config=author_dynamic_config)
        self.logger.info(f"🌡️  Temperature: {params['temperature']:.3f}")
        
        # Build prompt using unified builder for all components
        from shared.text.utils.prompt_builder import PromptBuilder

        enrichment_params = fact_enrichment_params
        
        # Build prompt (single pass)
        # Use explicit per-generation variation seed to avoid deterministic repetition.
        # Ensure a fresh variation seed per generation call to avoid length reuse
        generation_variation_seed = random.SystemRandom().randint(0, 2**31 - 1)
        if self._last_variation_seed is not None and generation_variation_seed == self._last_variation_seed:
            generation_variation_seed = random.SystemRandom().randint(0, 2**31 - 1)
        self._last_variation_seed = generation_variation_seed

        opening_style = self._select_opening_style(identifier, component_type)
        variation_pattern = self._select_variation_pattern(component_type)
        runtime_target_words = kwargs.get('target_words')
        length_override = runtime_target_words if isinstance(runtime_target_words, int) and runtime_target_words > 0 else None

        prompt = PromptBuilder.build_unified_prompt(
            topic=identifier,
            voice=voice,
            length=length_override,
            facts=facts,
            context=context,
            component_type=component_type,
            domain=self.domain,
            enrichment_params=enrichment_params,
            variation_seed=generation_variation_seed,
            humanness_layer=humanness_layer,
            faq_count=faq_count,
            item_data=item_data,  # Pass item_data for template placeholders
            opening_style=opening_style,
            variation_pattern=variation_pattern,
        )

        humanness_chars = len(humanness_layer) if isinstance(humanness_layer, str) else 0
        print(f"📊 Final prompt: {len(prompt):,} chars (humanness: {humanness_chars:,})")
        self.logger.info(f"📊 Final prompt: {len(prompt):,} chars (humanness: {humanness_chars:,})")
        self.logger.info(f"📝 Prompt built for {component_type}")
        
        # CRITICAL: Validate FULL ASSEMBLED PROMPT before API call
        print("\n" + "="*80)
        print("🔍 COMPREHENSIVE PROMPT VALIDATION (FULL PROMPT)")
        print("="*80)
        self.logger.info("\n" + "="*80)
        self.logger.info("🔍 COMPREHENSIVE PROMPT VALIDATION (FULL PROMPT)")
        self.logger.info("="*80)

        if skip_prompt_validation:
            print("⏩ Skipping prompt validation (retry speed mode)")
            self.logger.info("⏩ Skipping prompt validation (retry speed mode)")
        else:
            prompt_diagnostics_enabled = os.getenv('ZBEAM_PROMPT_DIAGNOSTICS', '').lower() in {'1', 'true', 'yes', 'on'}
            shared_validation = self.config.get('shared_domain_validation')
            if not isinstance(shared_validation, dict):
                raise KeyError("Missing required config block: shared_domain_validation")
            if 'min_description_words' not in shared_validation:
                raise KeyError("Missing required config key: shared_domain_validation.min_description_words")
            min_description_words = shared_validation['min_description_words']
            if not isinstance(min_description_words, int):
                raise TypeError("shared_domain_validation.min_description_words must be an integer")
            length_target = self.processing_config.get_component_length(component_type)
            skip_coherence_validation = length_target < min_description_words

            try:
                from shared.validation.content.prompt_coherence_validator import (
                    validate_prompt_coherence,
                )
                from shared.validation.content.prompt_validator import validate_text_prompt

                validation_result = validate_text_prompt(prompt)

                coherence_result = None
                if skip_coherence_validation:
                    print("\n🔗 COHERENCE VALIDATION: SKIPPED (short field)")
                    self.logger.info("🔗 COHERENCE VALIDATION: SKIPPED (short field)")
                else:
                    coherence_result = validate_prompt_coherence(prompt)

                print(f"\n📊 PROMPT METRICS:")
                print(f"   • Characters: {validation_result.prompt_length:,}")
                print(f"   • Words: {validation_result.word_count:,}")
                print(f"   • Estimated tokens: {validation_result.estimated_tokens:,}")
                print(f"   • Status: {validation_result.get_summary()}")
                self.logger.info(f"\n📊 PROMPT METRICS:")
                self.logger.info(f"   • Characters: {validation_result.prompt_length:,}")
                self.logger.info(f"   • Words: {validation_result.word_count:,}")
                self.logger.info(f"   • Estimated tokens: {validation_result.estimated_tokens:,}")
                self.logger.info(f"   • Status: {validation_result.get_summary()}")

                if prompt_diagnostics_enabled:
                    prompt_lines = prompt.splitlines()
                    print(f"\n📜 FULL PROMPT STRUCTURE:")
                    print(f"   • Total lines: {len(prompt_lines)}")
                    print(f"   • First 15 lines:")
                    for i, line in enumerate(prompt_lines[:15], 1):
                        print(f"      {i:2d}. {line[:100]}{'...' if len(line) > 100 else ''}")
                    if len(prompt_lines) > 15:
                        print(f"   • ... ({len(prompt_lines) - 15} more lines)")

                    self.logger.info(f"\n📜 FULL PROMPT STRUCTURE:")
                    self.logger.info(f"   • Total lines: {len(prompt_lines)}")
                    self.logger.info(f"   • First 10 lines:")
                    for i, line in enumerate(prompt_lines[:10], 1):
                        self.logger.info(f"      {i:2d}. {line[:100]}{'...' if len(line) > 100 else ''}")
                    if len(prompt_lines) > 10:
                        self.logger.info(f"   • ... ({len(prompt_lines) - 10} more lines)")

                    print(f"\n🔍 CRITICAL SECTIONS CHECK:")
                    if 'VOICE INSTRUCTIONS' in prompt or 'VOICE:' in prompt or 'voice_instruction' in prompt:
                        print("   • Voice instructions: ✅ PRESENT")
                        self.logger.info("   ✅ Voice instructions present in prompt")
                    else:
                        print("   • Voice instructions: ❌ MISSING")
                        self.logger.warning("   ⚠️  NO voice instructions found in prompt!")

                    if 'FORBIDDEN' in prompt.upper() or 'forbidden' in prompt:
                        print("   • Forbidden phrases: ✅ PRESENT")
                        self.logger.info("   ✅ Contains forbidden phrase instructions")
                    else:
                        print("   • Forbidden phrases: ❌ MISSING")
                        self.logger.warning("   ⚠️  NO forbidden phrase instructions found!")

                    if 'REQUIREMENTS:' in prompt.upper():
                        print("   • Component requirements: ✅ PRESENT")
                    else:
                        print("   • Component requirements: ❌ MISSING")

                if validation_result.issues:
                    print(f"\n⚠️  VALIDATION ISSUES ({len(validation_result.issues)} total):")
                    for i, issue in enumerate(validation_result.issues, 1):
                        print(f"   {i}. [{issue.severity.value}] {issue.message}")
                        if issue.suggestion:
                            print(f"      💡 {issue.suggestion}")

                    self.logger.info(f"\n⚠️  VALIDATION ISSUES ({len(validation_result.issues)} total):")
                    for i, issue in enumerate(validation_result.issues, 1):
                        self.logger.info(f"   {i}. [{issue.severity.value}] {issue.message}")
                        if issue.suggestion:
                            self.logger.info(f"      💡 {issue.suggestion}")
                else:
                    print(f"\n✅ No validation issues found")
                    self.logger.info(f"\n✅ No validation issues found")

                print("\n" + "="*80)
                self.logger.info("\n" + "="*80)

                if prompt_diagnostics_enabled:
                    import tempfile
                    with tempfile.NamedTemporaryFile(mode='w', suffix='_prompt.txt', delete=False, dir='/tmp') as f:
                        f.write(prompt)
                        prompt_file = f.name
                    print(f"📄 Full prompt saved to: {prompt_file}")
                    print(f"   View with: cat {prompt_file}")
                    self.logger.info(f"📄 Full prompt saved to: {prompt_file}\n")

                if not validation_result.is_valid:
                    if validation_result.has_critical_issues or validation_result.has_errors:
                        severity_label = "CRITICAL" if validation_result.has_critical_issues else "ERROR"
                        print(f"\n⚠️  {severity_label} VALIDATION ISSUES - AUTO-FIXING")
                        print(validation_result.format_report())
                        self.logger.warning(f"{severity_label} validation issues detected - attempting auto-fix")

                        from shared.validation.prompt_optimizer import optimize_prompt
                        optimized_prompt = optimize_prompt(prompt, validation_result)

                        if optimized_prompt != prompt:
                            print(f"\n✅ PROMPT AUTO-OPTIMIZED:")
                            print(f"   Original: {len(prompt):,} chars")
                            print(f"   Optimized: {len(optimized_prompt):,} chars")
                            print(f"   Reduction: {len(prompt) - len(optimized_prompt):,} chars ({100*(len(prompt)-len(optimized_prompt))/len(prompt):.1f}%)")
                            self.logger.info(f"Prompt optimized: {len(prompt)} → {len(optimized_prompt)} chars")
                            prompt = optimized_prompt

                            validation_result = validate_text_prompt(prompt)
                            if validation_result.has_critical_issues or validation_result.has_warnings:
                                print(f"   ⚠️  Still has issues after optimization")
                                self.logger.warning(f"Optimization insufficient - proceeding anyway")
                            else:
                                print(f"   ✅ Issues resolved")
                                self.logger.info(f"Issues resolved by optimization")

                        self._log_validation_issues(
                            validation_result,
                            'standard',
                            material=identifier,
                            component_type=component_type,
                            domain=self.domain
                        )
                    else:
                        print(f"\n💡 VALIDATION INFO (logged for learning)")
                        print(validation_result.format_report())
                        self.logger.info(f"Validation info detected: {validation_result.format_report()}")
                        self._log_validation_issues(
                            validation_result,
                            'standard',
                            material=identifier,
                            component_type=component_type,
                            domain=self.domain
                        )
                elif validation_result.has_warnings:
                    print(f"\n⚠️  VALIDATION WARNINGS (logged, no auto-fix)")
                    print(validation_result.format_report())
                    self.logger.warning(f"Validation warnings detected - no auto-fix")
                    self._log_validation_issues(
                        validation_result,
                        'standard',
                        material=identifier,
                        component_type=component_type,
                        domain=self.domain
                    )
                else:
                    print(f"   ✅ Standard validation passed")
                    self.logger.info("   ✅ Standard validation passed")

                if coherence_result is not None:
                    print(f"\n🔗 COHERENCE VALIDATION:")
                    print(f"   {coherence_result.get_summary()}")
                    self.logger.info(f"🔗 COHERENCE VALIDATION: {coherence_result.get_summary()}")

                    if not coherence_result.is_coherent:
                        critical_coherence = [i for i in coherence_result.issues if i.severity == "CRITICAL"]

                        if critical_coherence:
                            print(f"\n⚠️  CRITICAL COHERENCE ISSUES (logged for learning):")
                            for issue in critical_coherence:
                                print(f"   • [{issue.severity}] {issue.message}")
                                self.logger.warning(f"   [{issue.severity}] {issue.message}")

                            self.logger.warning(f"{len(critical_coherence)} critical coherence issues - logged for learning")
                            self._log_validation_issues(
                                coherence_result,
                                'coherence',
                                material=identifier,
                                component_type=component_type,
                                domain=self.domain
                            )
                        else:
                            print(f"\n⚠️  COHERENCE ISSUES DETECTED (logged for learning):")
                            for issue in coherence_result.issues:
                                if issue.severity in ["ERROR", "WARNING"]:
                                    print(f"   • [{issue.severity}] {issue.message}")
                                    self.logger.warning(f"   [{issue.severity}] {issue.message}")

                            self.logger.info("\n" + coherence_result.format_report())
                            self._log_validation_issues(
                                coherence_result,
                                'coherence',
                                material=identifier,
                                component_type=component_type,
                                domain=self.domain
                            )
                    else:
                        print(f"   ✅ Coherence validated successfully")
                        self.logger.info("   ✅ Coherence validated successfully")
            except ImportError as e:
                raise RuntimeError(
                    f"UniversalPromptValidator import failed - fail-fast architecture requires validation: {e}"
                ) from e
        
        # Make API call
        self.logger.info("📡 Making API request...")
        from shared.api.client import GenerationRequest
        
        # Calculate optimal max_tokens based on target length (reduces token waste)
        target_words = self.processing_config.get_component_length(component_type)
        
        # Allow 2.5x target for natural completion + safety margin
        # Average: 1 token ≈ 0.75 words, so words * 1.33 ≈ tokens
        optimal_max_tokens = int(target_words * 2.5 * 1.33)
        optimal_max_tokens = max(200, min(optimal_max_tokens, 4096))  # Clamp 200-4096
        
        try:
            request = GenerationRequest(
                prompt=prompt,
                max_tokens=optimal_max_tokens,  # Dynamic based on target length (was 4096)
                temperature=params['temperature'],
                **params['api_penalties']
            )
            
            response = self.api_client.generate(request)
        except Exception as e:
            raise ValueError(f"API call failed: {e}")
        
        # Extract content from APIResponse object
        if not response or not response.success or not response.content or not response.content.strip():
            raise ValueError("Empty or failed response from API")
        
        # Extract content using adapter
        try:
            content = self.adapter.extract_content(response.content, component_type)
        except Exception as e:
            raise ValueError(f"Content extraction failed: {e}")
        
        # Calculate word count (handle both string and dict content)
        if isinstance(content, dict):
            # Micro has before/after structure
            word_count = sum(len(str(v).split()) for v in content.values() if v)
            char_count = sum(len(str(v)) for v in content.values() if v)
        elif isinstance(content, list):
            # FAQ has list of Q&A dicts
            for qa in content:
                if not isinstance(qa, dict):
                    raise ValueError("FAQ content entries must be dictionaries")
                if 'answer' not in qa:
                    raise KeyError("FAQ entry missing required key: answer")
                if not isinstance(qa['answer'], str):
                    raise TypeError("FAQ entry 'answer' must be a string")
            word_count = sum(len(qa['answer'].split()) for qa in content)
            char_count = sum(len(qa['answer']) for qa in content)
        else:
            # String content (description, etc.)
            word_count = len(str(content).split())
            char_count = len(str(content))
        
        self.logger.info(f"✅ Generated: {char_count} chars, {word_count} words")
        
        return {
            'content': content,
            'length': char_count,
            'word_count': word_count,
            'saved': False,
            'temperature': params['temperature'],
            'prompt_used': prompt
        }
    
    def _save_to_yaml(self, identifier: str, component_type: str, content: Any):
        """
        Save generated content to domain data YAML file using domain adapter.
        
        Domain-aware: Uses adapter.write_component() which automatically:
        - Writes to correct YAML file (Materials.yaml, Contaminants.yaml, Settings.yaml, etc.)
        - Uses correct root key (materials, contamination_patterns, settings, etc.)
        - Performs atomic write with temp file
        - Syncs to frontmatter immediately (dual-write policy)
        """
        self.adapter.write_component(identifier, component_type, content)
    
    def _log_validation_issues(
        self, 
        validation_result, 
        validation_type: str,
        material: Optional[str] = None,
        component_type: Optional[str] = None,
        domain: str = 'materials'
    ):
        """
        Log validation issues to learning database for humanness optimizer feedback.
        
        This enables dynamic adaptation: validation issues feed into the humanness
        layer, which adjusts future prompts to address recurring problems.
        
        Args:
            validation_result: ValidationResult or CoherenceResult object
            validation_type: Type of validation ('standard' or 'coherence')
            material: Material/item name for correlation with Winston results
            component_type: Content type for correlation analysis
            domain: Content domain (materials, contaminants, settings)
        
        Design: Non-blocking - logs for learning, never raises exceptions
        """
        try:
            # Lazy import to avoid circular dependencies
            from postprocessing.detection.winston_feedback_db import (
                WinstonFeedbackDatabase,
            )
            
            db = WinstonFeedbackDatabase('z-beam.db')
            
            # Extract issues from validation result
            issues = []
            if hasattr(validation_result, 'issues'):
                for issue in validation_result.issues:
                    # Convert enum to string value for JSON serialization
                    severity = getattr(issue, 'severity', 'UNKNOWN')
                    if hasattr(severity, 'value'):
                        severity = severity.value
                    issues.append({
                        'severity': severity,
                        'message': getattr(issue, 'message', str(issue)),
                        'suggestion': getattr(issue, 'suggestion', None)
                    })
            
            # Log to prompt_validation_feedback table (auto-creates if not exists)
            db.log_prompt_validation(
                validation_type=validation_type,
                is_valid=getattr(validation_result, 'is_valid', True) or 
                        getattr(validation_result, 'is_coherent', True),
                issues=issues,
                prompt_length=getattr(validation_result, 'prompt_length', None),
                word_count=getattr(validation_result, 'word_count', None),
                estimated_tokens=getattr(validation_result, 'estimated_tokens', None),
                material=material,
                component_type=component_type,
                domain=domain
            )
            
            self.logger.info(f"   📊 Validation feedback logged ({len(issues)} issues) for humanness optimizer")
            
        except Exception as e:
            # Non-blocking: log error but continue generation
            self.logger.warning(f"   ⚠️  Could not log validation feedback: {e}")

